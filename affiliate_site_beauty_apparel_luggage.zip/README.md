# Amazon Affiliate Link-in-Bio Site (Beauty, Apparel, Luggage)
Three-category mobile-friendly site for Amazon affiliate links.

Categories:
- Beauty 💄
- Apparel & Accessories 👕
- Luggage & Bags 🧳

Replace `YOUR_AFFILIATE_LINK_*` in HTML files with your actual affiliate links.
Then upload to GitHub Pages for your Instagram bio.

Generated on 2025-08-14 08:28:52
