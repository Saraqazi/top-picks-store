// Simple client-side search across visible cards
const input = document.querySelector('[data-search]');
if (input){
  input.addEventListener('input', () => {
    const q = input.value.toLowerCase();
    document.querySelectorAll('.card').forEach(c => {
      const text = c.innerText.toLowerCase();
      c.style.display = text.includes(q) ? '' : 'none';
    });
  });
}
